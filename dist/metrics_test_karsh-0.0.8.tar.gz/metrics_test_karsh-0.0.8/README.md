Basic Functions Completed.
Clean up first then proceed to improve.